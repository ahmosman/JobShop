#pragma once
struct Job
{
	int machine;
	int duration;
	bool in_schedule = false;
};

